﻿using UnityEngine;
using System.Collections;

public interface IWeapon {

	void attack (Vector2 direction);
	void triggerUp ();

}
